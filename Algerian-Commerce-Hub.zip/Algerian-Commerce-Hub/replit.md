# TijariDZ

A SaaS e-commerce platform for Algerian merchants — multi-tenant, mobile-first, dark-themed.

## Run & Operate

- `Start application` workflow — Flask app on port 8000
- `cd artifacts/flask-store && python run.py` — run manually
- `pnpm --filter @workspace/api-server run dev` — Node.js API server (port 5000)

## Stack

- **Backend**: Python 3.11, Flask 3.0, SQLAlchemy, Flask-Login
- **Database**: PostgreSQL (Replit managed)
- **Frontend**: Jinja2 templates, Tailwind CSS (CDN), dark theme
- **pnpm workspaces**: Node.js 24, TypeScript 5.9 (for api-server scaffold)

## Where things live

- `artifacts/flask-store/` — Main Flask SaaS application
- `artifacts/flask-store/app/models/` — User, Store, Subscription, Product, Order
- `artifacts/flask-store/app/routes/` — landing, auth, dashboard, store
- `artifacts/flask-store/app/templates/` — Jinja2 HTML templates
- `artifacts/flask-store/config.py` — App configuration
- `artifacts/flask-store/run.py` — Entry point (creates DB tables on startup)

## Architecture decisions

- **Multi-tenant isolation**: Every query in routes is scoped to `current_user.id` — merchants can only see their own data.
- **SQLAlchemy ORM**: db.create_all() on startup; no migration framework needed for development.
- **Tailwind CSS via CDN**: No build step required; Play CDN works for production-grade styling.
- **Flask-Login**: Session-based auth with `@login_required` on all protected routes.
- **Slugified store URLs**: Store slugs are auto-generated from names with dedup counter.

## Product

- Landing page (dark theme): hero, stats (+8000 merchants), features, pricing, FAQ, CTA
- Auth: register, login, logout — full form validation
- Vendor dashboard: total orders, revenue, product count, pending orders, recent orders table
- Store management: create store (on first login), edit store info, settings (toggle active, subscription tiers)
- 5 DB models: User, Store, Subscription, Product, Order (with order_products join table)

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- `run.py` calls `db.create_all()` on startup — all tables are created automatically.
- `DATABASE_URL` env var is set by the Replit DB provision; Flask reads it via `config.py`.
- `SESSION_SECRET` is already set as a secret — Flask uses it for session signing.
- After code changes, the Flask dev server auto-reloads (debug=True).
- Tailwind CDN is used — no build step needed, but add `tailwind.config` via the script tag.

## Pointers

- See `artifacts/flask-store/app/models/` for DB schema
- Pricing plans defined in `app/models/subscription.py` → `Subscription.PLANS`
- Wilaya list and categories in `app/routes/store.py`
