import os
from app import create_app, db

app = create_app(os.environ.get('FLASK_ENV', 'development'))

with app.app_context():
    db.create_all()

    migrations = [
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS is_admin BOOLEAN NOT NULL DEFAULT FALSE",
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS is_suspended BOOLEAN NOT NULL DEFAULT FALSE",
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS suspension_reason TEXT",
        "ALTER TABLE stores ADD COLUMN IF NOT EXISTS is_suspended BOOLEAN NOT NULL DEFAULT FALSE",
        "ALTER TABLE stores ADD COLUMN IF NOT EXISTS suspension_reason TEXT",
        "ALTER TABLE stores ADD COLUMN IF NOT EXISTS verification_status VARCHAR(50) NOT NULL DEFAULT 'pending'",
        "ALTER TABLE stores ADD COLUMN IF NOT EXISTS verified_at TIMESTAMP",
        "ALTER TABLE stores ADD COLUMN IF NOT EXISTS primary_color VARCHAR(20) DEFAULT '#2563eb'",
        "ALTER TABLE stores ADD COLUMN IF NOT EXISTS secondary_color VARCHAR(20) DEFAULT '#7c3aed'",
        "ALTER TABLE stores ADD COLUMN IF NOT EXISTS whatsapp VARCHAR(30)",
        "ALTER TABLE stores ADD COLUMN IF NOT EXISTS business_hours TEXT",
        "ALTER TABLE stores ADD COLUMN IF NOT EXISTS facebook_url VARCHAR(255)",
        "ALTER TABLE stores ADD COLUMN IF NOT EXISTS instagram_url VARCHAR(255)",
        "ALTER TABLE stores ADD COLUMN IF NOT EXISTS tiktok_url VARCHAR(255)",
        "ALTER TABLE stores ADD COLUMN IF NOT EXISTS youtube_url VARCHAR(255)",
        "ALTER TABLE stores ADD COLUMN IF NOT EXISTS telegram_url VARCHAR(255)",
        "ALTER TABLE stores ADD COLUMN IF NOT EXISTS free_shipping_threshold NUMERIC(10,2) DEFAULT 0",
        "ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS trial_ends_at TIMESTAMP",
        "ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS billing_cycle VARCHAR(20) DEFAULT 'monthly'",
        "ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS cancelled_at TIMESTAMP",
        "ALTER TABLE orders ADD COLUMN IF NOT EXISTS commune VARCHAR(100)",
        "ALTER TABLE orders ADD COLUMN IF NOT EXISTS shipping_cost NUMERIC(10,2) DEFAULT 0",
        "ALTER TABLE orders ADD COLUMN IF NOT EXISTS delivery_estimate VARCHAR(50)",
    ]
    with db.engine.connect() as conn:
        for sql in migrations:
            conn.execute(db.text(sql))
        conn.commit()

    from app.models.user import User
    if not User.query.filter_by(is_admin=True).first():
        admin = User(
            email='admin@tijaridz.com',
            username='admin',
            full_name='Admin TijariDZ',
            is_admin=True,
            is_verified=True,
        )
        admin.set_password('Admin@TijariDZ2024!')
        db.session.add(admin)
        db.session.commit()
        print('[TijariDZ] Default admin created: admin@tijaridz.com / Admin@TijariDZ2024!')

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8000))
    app.run(host='0.0.0.0', port=port, debug=True)
