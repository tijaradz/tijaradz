import os
import re
from datetime import datetime, timedelta
from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app
from flask_login import login_required, current_user
from app import db
from app.models.store import Store
from app.models.subscription import Subscription
from app.utils import notify

store_bp = Blueprint('store', __name__)

WILAYAS = [
    'Adrar', 'Chlef', 'Laghouat', 'Oum El Bouaghi', 'Batna', 'Béjaïa', 'Biskra',
    'Béchar', 'Blida', 'Bouira', 'Tamanrasset', 'Tébessa', 'Tlemcen', 'Tiaret',
    'Tizi Ouzou', 'Alger', 'Djelfa', 'Jijel', 'Sétif', 'Saïda', 'Skikda',
    'Sidi Bel Abbès', 'Annaba', 'Guelma', 'Constantine', 'Médéa', 'Mostaganem',
    "M'Sila", 'Mascara', 'Ouargla', 'Oran', 'El Bayadh', 'Illizi',
    'Bordj Bou Arréridj', 'Boumerdès', 'El Tarf', 'Tindouf', 'Tissemsilt',
    'El Oued', 'Khenchela', 'Souk Ahras', 'Tipaza', 'Mila', 'Aïn Defla',
    'Naâma', 'Aïn Témouchent', 'Ghardaïa', 'Relizane',
]

CATEGORIES = [
    'Mode & Vêtements', 'Électronique', 'Alimentation & Boissons', 'Maison & Jardin',
    'Beauté & Soins', 'Sport & Loisirs', 'Jouets & Enfants', 'Automobile',
    'Livres & Médias', 'Santé', 'Artisanat', 'Autre',
]

ALLOWED_IMG = {'png', 'jpg', 'jpeg', 'gif', 'webp'}


def slugify(text):
    text = text.lower().strip()
    text = re.sub(r'[^\w\s-]', '', text)
    text = re.sub(r'[\s_-]+', '-', text)
    return text


def allowed_image(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_IMG


def save_store_image(file, store_id, kind):
    if not file or file.filename == '':
        return None
    if not allowed_image(file.filename):
        return None
    ext = file.filename.rsplit('.', 1)[1].lower()
    folder = os.path.join(current_app.config['STORE_UPLOAD_FOLDER'], str(store_id))
    os.makedirs(folder, exist_ok=True)
    file.save(os.path.join(folder, f'{kind}.{ext}'))
    return f'/static/uploads/stores/{store_id}/{kind}.{ext}'


@store_bp.route('/create', methods=['GET', 'POST'])
@login_required
def create():
    existing = Store.query.filter_by(user_id=current_user.id).first()
    if existing:
        return redirect(url_for('dashboard.index'))

    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        description = request.form.get('description', '').strip()
        phone = request.form.get('phone', '').strip()
        email = request.form.get('email', '').strip()
        address = request.form.get('address', '').strip()
        wilaya = request.form.get('wilaya', '').strip()
        category = request.form.get('category', '').strip()

        errors = []
        if not name:
            errors.append('Le nom de la boutique est requis.')
        if len(name) < 3:
            errors.append('Le nom doit contenir au moins 3 caractères.')
        if errors:
            for e in errors:
                flash(e, 'error')
            return render_template('store/create.html', wilayas=WILAYAS, categories=CATEGORIES)

        base_slug = slugify(name)
        slug = base_slug
        counter = 1
        while Store.query.filter_by(slug=slug).first():
            slug = f'{base_slug}-{counter}'
            counter += 1

        store = Store(user_id=current_user.id, name=name, slug=slug,
                      description=description, phone=phone, email=email,
                      address=address, wilaya=wilaya, category=category)
        db.session.add(store)
        db.session.flush()
        db.session.add(Subscription(store_id=store.id, plan='starter', status='active', price_dzd=0))
        db.session.commit()
        flash('Boutique créée avec succès !', 'success')
        return redirect(url_for('dashboard.index'))

    return render_template('store/create.html', wilayas=WILAYAS, categories=CATEGORIES)


@store_bp.route('/edit', methods=['GET', 'POST'])
@login_required
def edit():
    store = Store.query.filter_by(user_id=current_user.id).first_or_404()
    if request.method == 'POST':
        store.name = request.form.get('name', '').strip()
        store.description = request.form.get('description', '').strip()
        store.phone = request.form.get('phone', '').strip()
        store.email = request.form.get('email', '').strip()
        store.address = request.form.get('address', '').strip()
        store.wilaya = request.form.get('wilaya', '').strip()
        store.category = request.form.get('category', '').strip()
        db.session.commit()
        flash('Boutique mise à jour avec succès !', 'success')
        return redirect(url_for('dashboard.index'))
    return render_template('store/edit.html', store=store, wilayas=WILAYAS, categories=CATEGORIES)


@store_bp.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    store = Store.query.filter_by(user_id=current_user.id).first_or_404()
    subscription = store.subscription

    if request.method == 'POST':
        action = request.form.get('action')

        if action == 'toggle_store':
            store.is_active = not store.is_active
            db.session.commit()
            flash(f'Boutique {"activée" if store.is_active else "désactivée"}.', 'success')

        elif action == 'update_customization':
            logo_url = save_store_image(request.files.get('logo'), store.id, 'logo')
            banner_url = save_store_image(request.files.get('banner'), store.id, 'banner')
            if logo_url:
                store.logo_url = logo_url
            if banner_url:
                store.banner_url = banner_url
            primary = request.form.get('primary_color', '').strip()
            secondary = request.form.get('secondary_color', '').strip()
            if primary and primary.startswith('#'):
                store.primary_color = primary
            if secondary and secondary.startswith('#'):
                store.secondary_color = secondary
            db.session.commit()
            flash('Personnalisation enregistrée.', 'success')

        elif action == 'update_contact':
            store.whatsapp = request.form.get('whatsapp', '').strip()
            store.business_hours = request.form.get('business_hours', '').strip()
            store.facebook_url = request.form.get('facebook_url', '').strip()
            store.instagram_url = request.form.get('instagram_url', '').strip()
            store.tiktok_url = request.form.get('tiktok_url', '').strip()
            store.youtube_url = request.form.get('youtube_url', '').strip()
            store.telegram_url = request.form.get('telegram_url', '').strip()
            db.session.commit()
            flash('Contact et réseaux sociaux enregistrés.', 'success')

        elif action == 'update_shipping':
            try:
                threshold = float(request.form.get('free_shipping_threshold', 0))
                store.free_shipping_threshold = max(0, threshold)
            except ValueError:
                store.free_shipping_threshold = 0
            db.session.commit()
            flash('Paramètres de livraison enregistrés.', 'success')

        elif action == 'upgrade_plan':
            new_plan = request.form.get('plan')
            billing_cycle = request.form.get('billing_cycle', 'monthly')
            if new_plan not in Subscription.PLANS:
                flash('Plan invalide.', 'error')
                return redirect(url_for('store.settings'))
            if not subscription:
                subscription = Subscription(store_id=store.id)
                db.session.add(subscription)
            plan_info = Subscription.PLANS[new_plan]
            now = datetime.utcnow()
            trial_days = plan_info.get('trial_days', 0)
            if (new_plan != 'starter' and trial_days > 0
                    and subscription.status == 'active'
                    and subscription.plan == 'starter'
                    and not subscription.trial_ends_at):
                subscription.status = 'trial'
                subscription.trial_ends_at = now + timedelta(days=trial_days)
                flash_msg = f'Essai {plan_info["name"]} activé pour {trial_days} jours !'
            elif new_plan == 'starter':
                subscription.status = 'active'
                subscription.expires_at = None
                flash_msg = 'Retour au plan Starter.'
            else:
                subscription.status = 'active'
                subscription.expires_at = now + timedelta(days=365 if billing_cycle == 'yearly' else 30)
                flash_msg = f'Abonnement {plan_info["name"]} activé !'
            subscription.plan = new_plan
            subscription.price_dzd = plan_info['price']
            subscription.billing_cycle = billing_cycle
            db.session.commit()
            notify(current_user.id, 'subscription_upgrade', f'Abonnement {plan_info["name"]} 🚀',
                   flash_msg, store_id=store.id, action_url=url_for('store.settings'))
            db.session.commit()
            flash(flash_msg, 'success')

        elif action == 'cancel_plan':
            if subscription and subscription.plan != 'starter':
                subscription.plan = 'starter'
                subscription.status = 'active'
                subscription.price_dzd = 0
                subscription.expires_at = None
                subscription.cancelled_at = datetime.utcnow()
                db.session.commit()
                flash('Abonnement annulé. Retour au plan Starter.', 'info')

    return render_template('store/settings.html',
                           store=store,
                           subscription=subscription,
                           PLANS=Subscription.PLANS)
