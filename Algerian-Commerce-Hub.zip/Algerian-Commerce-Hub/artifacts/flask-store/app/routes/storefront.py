import random
import string
from datetime import datetime, timedelta
from flask import (Blueprint, render_template, redirect, url_for,
                   flash, request, session, abort)
from app import db
from app.models.store import Store
from app.models.product import Product, order_products
from app.models.order import Order
from app.utils import notify
from app.shipping import (
    get_shipping_info, shipping_rates_json,
    build_whatsapp_url, build_order_whatsapp_message,
)

storefront_bp = Blueprint('storefront', __name__)

WILAYAS = [
    'Adrar', 'Chlef', 'Laghouat', 'Oum El Bouaghi', 'Batna', 'Béjaïa', 'Biskra',
    'Béchar', 'Blida', 'Bouira', 'Tamanrasset', 'Tébessa', 'Tlemcen', 'Tiaret',
    'Tizi Ouzou', 'Alger', 'Djelfa', 'Jijel', 'Sétif', 'Saïda', 'Skikda',
    'Sidi Bel Abbès', 'Annaba', 'Guelma', 'Constantine', 'Médéa', 'Mostaganem',
    "M'Sila", 'Mascara', 'Ouargla', 'Oran', 'El Bayadh', 'Illizi',
    'Bordj Bou Arréridj', 'Boumerdès', 'El Tarf', 'Tindouf', 'Tissemsilt',
    'El Oued', 'Khenchela', 'Souk Ahras', 'Tipaza', 'Mila', 'Aïn Defla',
    'Naâma', 'Aïn Témouchent', 'Ghardaïa', 'Relizane',
]


# ── Helpers ──────────────────────────────────────────────────────────────────

def _cart_key(slug):
    return f'cart_{slug}'


def get_cart(slug):
    return session.get(_cart_key(slug), {})


def save_cart(slug, cart):
    session[_cart_key(slug)] = cart
    session.modified = True


def cart_count(slug):
    return sum(v['qty'] for v in get_cart(slug).values())


def cart_subtotal(slug):
    return sum(float(v['price']) * v['qty'] for v in get_cart(slug).values())


def _get_store_or_404(slug):
    store = Store.query.filter_by(slug=slug).first_or_404()
    if store.is_suspended or not store.is_active:
        abort(404)
    return store


def _generate_order_number():
    date_part = datetime.utcnow().strftime('%Y%m%d')
    rand_part = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
    return f'TJR-{date_part}-{rand_part}'


def _create_order_from_items(store, enriched, subtotal, form_data):
    """Shared order-creation logic used by checkout and quick order."""
    wilaya = form_data['wilaya']
    shipping_info = get_shipping_info(
        wilaya,
        free_threshold=float(store.free_shipping_threshold or 0),
        order_subtotal=subtotal,
    )
    shipping_cost = shipping_info['fee']
    total = subtotal + shipping_cost

    order = Order(
        store_id=store.id,
        order_number=_generate_order_number(),
        customer_name=form_data['customer_name'],
        customer_phone=form_data['customer_phone'],
        wilaya=wilaya,
        commune=form_data.get('commune', ''),
        customer_address=form_data['address'],
        notes=form_data.get('notes', ''),
        total_amount=total,
        shipping_cost=shipping_cost,
        delivery_estimate=shipping_info['days'],
        status='pending',
        payment_method='cash_on_delivery',
    )
    db.session.add(order)
    db.session.flush()

    for entry in enriched:
        db.session.execute(
            order_products.insert().values(
                order_id=order.id,
                product_id=int(entry['id']),
                quantity=entry['qty'],
                unit_price=entry['product'].price,
            )
        )

    db.session.commit()

    # Notify merchant (in-app)
    notify(
        store.user_id,
        'new_order',
        f'Nouvelle commande #{order.order_number}',
        f'{form_data["customer_name"]} — {total:.0f} DZD ({wilaya})',
        store_id=store.id,
        action_url=url_for('orders.detail', order_id=order.id),
    )
    db.session.commit()

    return order, shipping_info


# ── Homepage ──────────────────────────────────────────────────────────────────

@storefront_bp.route('/store/<slug>')
def home(slug):
    store = _get_store_or_404(slug)
    query = request.args.get('q', '').strip()
    selected_cat = request.args.get('cat', '').strip()

    products_q = store.products.filter_by(is_active=True)
    if query:
        products_q = products_q.filter(
            db.or_(
                Product.name.ilike(f'%{query}%'),
                Product.description.ilike(f'%{query}%'),
            )
        )
    if selected_cat:
        products_q = products_q.filter_by(category=selected_cat)

    products = products_q.order_by(Product.created_at.desc()).all()

    categories = db.session.query(Product.category).filter(
        Product.store_id == store.id,
        Product.is_active == True,
        Product.category != None,
        Product.category != '',
    ).distinct().all()
    categories = sorted([c[0] for c in categories if c[0]])

    featured = store.products.filter(
        Product.is_active == True,
        Product.stock > 0,
    ).order_by(Product.created_at.desc()).limit(8).all()

    free_threshold = float(store.free_shipping_threshold or 0)

    return render_template('storefront/home.html',
                           store=store,
                           products=products,
                           featured=featured,
                           categories=categories,
                           query=query,
                           selected_cat=selected_cat,
                           cart_count=cart_count(slug),
                           free_threshold=free_threshold)


# ── Product page ──────────────────────────────────────────────────────────────

@storefront_bp.route('/store/<slug>/product/<int:product_id>')
def product(slug, product_id):
    store = _get_store_or_404(slug)
    item = Product.query.filter_by(id=product_id, store_id=store.id, is_active=True).first_or_404()

    related = store.products.filter(
        Product.is_active == True,
        Product.id != item.id,
        Product.category == item.category,
    ).limit(4).all()
    if not related:
        related = store.products.filter(
            Product.is_active == True,
            Product.id != item.id,
        ).limit(4).all()

    return render_template('storefront/product.html',
                           store=store,
                           product=item,
                           related=related,
                           cart_count=cart_count(slug),
                           shipping_rates=shipping_rates_json(),
                           free_threshold=float(store.free_shipping_threshold or 0))


# ── Cart ──────────────────────────────────────────────────────────────────────

@storefront_bp.route('/store/<slug>/cart')
def cart(slug):
    store = _get_store_or_404(slug)
    cart_items = get_cart(slug)
    enriched = []
    total = 0
    for pid, item in cart_items.items():
        p = Product.query.get(int(pid))
        if p and p.store_id == store.id and p.is_active:
            subtotal = float(p.price) * item['qty']
            total += subtotal
            enriched.append({
                'id': pid, 'name': p.name, 'price': float(p.price),
                'qty': item['qty'], 'image_url': p.image_url,
                'stock': p.stock, 'subtotal': subtotal,
            })
    free_threshold = float(store.free_shipping_threshold or 0)
    return render_template('storefront/cart.html',
                           store=store,
                           cart_items=enriched,
                           total=total,
                           cart_count=cart_count(slug),
                           free_threshold=free_threshold)


@storefront_bp.route('/store/<slug>/cart/add', methods=['POST'])
def cart_add(slug):
    store = _get_store_or_404(slug)
    product_id = str(request.form.get('product_id', ''))
    try:
        qty = max(1, int(request.form.get('qty', 1)))
    except ValueError:
        qty = 1
    p = Product.query.filter_by(id=int(product_id), store_id=store.id, is_active=True).first_or_404()
    cart = get_cart(slug)
    if product_id in cart:
        cart[product_id]['qty'] = min(cart[product_id]['qty'] + qty, p.stock or 99)
    else:
        cart[product_id] = {'name': p.name, 'price': float(p.price),
                             'qty': min(qty, p.stock or 99), 'image_url': p.image_url or ''}
    save_cart(slug, cart)
    redirect_to = request.form.get('redirect_to', 'product')
    if redirect_to == 'cart':
        return redirect(url_for('storefront.cart', slug=slug))
    return redirect(url_for('storefront.product', slug=slug, product_id=p.id))


@storefront_bp.route('/store/<slug>/cart/update', methods=['POST'])
def cart_update(slug):
    _get_store_or_404(slug)
    product_id = str(request.form.get('product_id', ''))
    try:
        qty = int(request.form.get('qty', 1))
    except ValueError:
        qty = 1
    cart = get_cart(slug)
    if product_id in cart:
        if qty <= 0:
            del cart[product_id]
        else:
            cart[product_id]['qty'] = qty
        save_cart(slug, cart)
    return redirect(url_for('storefront.cart', slug=slug))


@storefront_bp.route('/store/<slug>/cart/remove', methods=['POST'])
def cart_remove(slug):
    _get_store_or_404(slug)
    product_id = str(request.form.get('product_id', ''))
    cart = get_cart(slug)
    cart.pop(product_id, None)
    save_cart(slug, cart)
    return redirect(url_for('storefront.cart', slug=slug))


# ── Checkout ──────────────────────────────────────────────────────────────────

@storefront_bp.route('/store/<slug>/checkout', methods=['GET', 'POST'])
def checkout(slug):
    store = _get_store_or_404(slug)
    cart_items = get_cart(slug)
    if not cart_items:
        flash('Votre panier est vide.', 'warning')
        return redirect(url_for('storefront.home', slug=slug))

    enriched = []
    subtotal = 0
    for pid, item in cart_items.items():
        p = Product.query.get(int(pid))
        if p and p.store_id == store.id and p.is_active:
            s = float(p.price) * item['qty']
            subtotal += s
            enriched.append({'id': pid, 'product': p, 'qty': item['qty'], 'subtotal': s})

    if not enriched:
        save_cart(slug, {})
        return redirect(url_for('storefront.home', slug=slug))

    if request.method == 'POST':
        customer_name = request.form.get('customer_name', '').strip()
        customer_phone = request.form.get('customer_phone', '').strip()
        wilaya = request.form.get('wilaya', '').strip()
        commune = request.form.get('commune', '').strip()
        address = request.form.get('address', '').strip()
        notes = request.form.get('notes', '').strip()

        errors = []
        if not customer_name:
            errors.append('Le nom est requis.')
        if not customer_phone:
            errors.append('Le numéro de téléphone est requis.')
        if not wilaya:
            errors.append('La wilaya est requise.')
        if not address:
            errors.append("L'adresse est requise.")

        if errors:
            for e in errors:
                flash(e, 'error')
            shipping_preview = get_shipping_info(wilaya or 'Alger',
                                                 float(store.free_shipping_threshold or 0), subtotal)
            return render_template('storefront/checkout.html',
                                   store=store, cart_items=enriched, subtotal=subtotal,
                                   wilayas=WILAYAS, cart_count=cart_count(slug),
                                   form=request.form, shipping_rates=shipping_rates_json(),
                                   free_threshold=float(store.free_shipping_threshold or 0),
                                   shipping_preview=shipping_preview)

        form_data = {'customer_name': customer_name, 'customer_phone': customer_phone,
                     'wilaya': wilaya, 'commune': commune, 'address': address, 'notes': notes}
        order, shipping_info = _create_order_from_items(store, enriched, subtotal, form_data)
        save_cart(slug, {})
        return redirect(url_for('storefront.order_success', slug=slug, order_number=order.order_number))

    shipping_preview = get_shipping_info('Alger', float(store.free_shipping_threshold or 0), subtotal)
    return render_template('storefront/checkout.html',
                           store=store, cart_items=enriched, subtotal=subtotal,
                           wilayas=WILAYAS, cart_count=cart_count(slug),
                           form={}, shipping_rates=shipping_rates_json(),
                           free_threshold=float(store.free_shipping_threshold or 0),
                           shipping_preview=shipping_preview)


# ── Quick Order ───────────────────────────────────────────────────────────────

@storefront_bp.route('/store/<slug>/quick-order/<int:product_id>', methods=['GET', 'POST'])
def quick_order(slug, product_id):
    store = _get_store_or_404(slug)
    item = Product.query.filter_by(id=product_id, store_id=store.id, is_active=True).first_or_404()

    if item.stock == 0:
        flash('Ce produit est épuisé.', 'warning')
        return redirect(url_for('storefront.product', slug=slug, product_id=product_id))

    if request.method == 'POST':
        try:
            qty = max(1, min(int(request.form.get('qty', 1)), item.stock or 99))
        except ValueError:
            qty = 1
        customer_name = request.form.get('customer_name', '').strip()
        customer_phone = request.form.get('customer_phone', '').strip()
        wilaya = request.form.get('wilaya', '').strip()
        commune = request.form.get('commune', '').strip()
        address = request.form.get('address', '').strip()
        notes = request.form.get('notes', '').strip()

        errors = []
        if not customer_name:
            errors.append('Le nom est requis.')
        if not customer_phone:
            errors.append('Le téléphone est requis.')
        if not wilaya:
            errors.append('La wilaya est requise.')
        if not address:
            errors.append("L'adresse est requise.")

        if errors:
            for e in errors:
                flash(e, 'error')
            subtotal = float(item.price) * qty
            return render_template('storefront/quick_order.html',
                                   store=store, product=item,
                                   wilayas=WILAYAS, cart_count=cart_count(slug),
                                   form=request.form,
                                   shipping_rates=shipping_rates_json(),
                                   free_threshold=float(store.free_shipping_threshold or 0),
                                   subtotal=subtotal)

        subtotal = float(item.price) * qty
        enriched = [{'id': str(item.id), 'product': item, 'qty': qty, 'subtotal': subtotal}]
        form_data = {'customer_name': customer_name, 'customer_phone': customer_phone,
                     'wilaya': wilaya, 'commune': commune, 'address': address, 'notes': notes}
        order, _ = _create_order_from_items(store, enriched, subtotal, form_data)
        return redirect(url_for('storefront.order_success', slug=slug, order_number=order.order_number))

    subtotal = float(item.price)
    return render_template('storefront/quick_order.html',
                           store=store, product=item,
                           wilayas=WILAYAS, cart_count=cart_count(slug),
                           form={}, shipping_rates=shipping_rates_json(),
                           free_threshold=float(store.free_shipping_threshold or 0),
                           subtotal=subtotal)


# ── Order Success ─────────────────────────────────────────────────────────────

@storefront_bp.route('/store/<slug>/order/<order_number>')
def order_success(slug, order_number):
    store = Store.query.filter_by(slug=slug).first_or_404()
    order = Order.query.filter_by(order_number=order_number, store_id=store.id).first_or_404()

    rows = db.session.execute(
        db.select(order_products).where(order_products.c.order_id == order.id)
    ).fetchall()
    items = []
    for row in rows:
        p = Product.query.get(row.product_id)
        if p:
            items.append({'product': p, 'qty': row.quantity, 'unit_price': float(row.unit_price)})

    # Build WhatsApp notification URL if store has whatsapp
    wa_url = None
    if store.whatsapp:
        msg = build_order_whatsapp_message(order, items)
        wa_url = build_whatsapp_url(store.whatsapp, msg)

    # Estimated delivery date
    estimated_date = None
    if order.delivery_estimate:
        try:
            max_days = int(order.delivery_estimate.split('-')[-1].replace(' jours', '').strip())
            estimated_date = (order.created_at + timedelta(days=max_days)).strftime('%d/%m/%Y')
        except Exception:
            pass

    return render_template('storefront/order_success.html',
                           store=store, order=order, items=items,
                           wa_url=wa_url, estimated_date=estimated_date,
                           cart_count=0)
