from datetime import datetime, timedelta
from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from app import db
from app.models.user import User
from app.models.store import Store
from app.models.subscription import Subscription
from app.models.order import Order
from app.models.product import Product
from app.models.notification import Notification
from app.utils import admin_required, notify

admin_bp = Blueprint('admin', __name__)


@admin_bp.route('/')
@login_required
@admin_required
def dashboard():
    total_merchants = User.query.filter_by(is_admin=False).count()
    total_stores = Store.query.count()
    active_stores = Store.query.filter_by(is_active=True, is_suspended=False).count()
    suspended_stores = Store.query.filter_by(is_suspended=True).count()
    total_orders = Order.query.count()
    total_products = Product.query.count()

    total_revenue = db.session.query(db.func.sum(Order.total_amount)).filter(
        Order.status == 'completed'
    ).scalar() or 0

    plan_stats = {}
    for plan in ['starter', 'professional', 'business']:
        plan_stats[plan] = Subscription.query.filter_by(plan=plan).count()

    status_stats = {}
    for status in ['active', 'trial', 'expired', 'suspended', 'cancelled']:
        status_stats[status] = Subscription.query.filter_by(status=status).count()

    pending_verification = Store.query.filter_by(verification_status='pending').count()

    now = datetime.utcnow()
    new_merchants_month = User.query.filter(
        User.is_admin == False,
        User.created_at >= now.replace(day=1, hour=0, minute=0, second=0)
    ).count()

    recent_merchants = User.query.filter_by(is_admin=False).order_by(User.created_at.desc()).limit(8).all()
    recent_orders = Order.query.order_by(Order.created_at.desc()).limit(8).all()

    monthly_signups = db.session.query(
        db.func.to_char(User.created_at, 'Mon YY').label('month'),
        db.func.count(User.id).label('count')
    ).filter(
        User.is_admin == False,
        User.created_at >= datetime.utcnow() - timedelta(days=180)
    ).group_by(
        db.func.date_trunc('month', User.created_at),
        db.func.to_char(User.created_at, 'Mon YY')
    ).order_by(db.func.date_trunc('month', User.created_at)).all()

    signup_labels = [r.month for r in monthly_signups]
    signup_data = [r.count for r in monthly_signups]

    return render_template('admin/dashboard.html',
        total_merchants=total_merchants,
        total_stores=total_stores,
        active_stores=active_stores,
        suspended_stores=suspended_stores,
        total_orders=total_orders,
        total_products=total_products,
        total_revenue=total_revenue,
        plan_stats=plan_stats,
        status_stats=status_stats,
        pending_verification=pending_verification,
        new_merchants_month=new_merchants_month,
        recent_merchants=recent_merchants,
        recent_orders=recent_orders,
        signup_labels=signup_labels,
        signup_data=signup_data,
    )


@admin_bp.route('/merchants')
@login_required
@admin_required
def merchants():
    search = request.args.get('search', '').strip()
    status = request.args.get('status', '').strip()
    page = request.args.get('page', 1, type=int)

    query = User.query.filter_by(is_admin=False)
    if search:
        query = query.filter(db.or_(
            User.email.ilike(f'%{search}%'),
            User.full_name.ilike(f'%{search}%'),
            User.username.ilike(f'%{search}%'),
        ))
    if status == 'suspended':
        query = query.filter_by(is_suspended=True)
    elif status == 'active':
        query = query.filter_by(is_suspended=False)

    merchants = query.order_by(User.created_at.desc()).paginate(page=page, per_page=20, error_out=False)
    return render_template('admin/merchants.html', merchants=merchants, search=search, status_filter=status)


@admin_bp.route('/merchants/<int:user_id>')
@login_required
@admin_required
def merchant_detail(user_id):
    merchant = User.query.filter_by(id=user_id, is_admin=False).first_or_404()
    stores = Store.query.filter_by(user_id=user_id).all()
    return render_template('admin/merchant_detail.html', merchant=merchant, stores=stores)


@admin_bp.route('/merchants/<int:user_id>/suspend', methods=['POST'])
@login_required
@admin_required
def suspend_merchant(user_id):
    merchant = User.query.filter_by(id=user_id, is_admin=False).first_or_404()
    reason = request.form.get('reason', 'Violation des conditions d\'utilisation.')
    merchant.is_suspended = not merchant.is_suspended
    merchant.suspension_reason = reason if merchant.is_suspended else None
    if merchant.is_suspended:
        notify(merchant.id, 'store_suspended', 'Compte suspendu',
               f'Votre compte a été suspendu. Raison: {reason}', action_url=url_for('dashboard.index'))
    db.session.commit()
    status = 'suspendu' if merchant.is_suspended else 'réactivé'
    flash(f'Compte {status}.', 'success')
    return redirect(url_for('admin.merchant_detail', user_id=user_id))


@admin_bp.route('/stores')
@login_required
@admin_required
def stores():
    search = request.args.get('search', '').strip()
    verification = request.args.get('verification', '').strip()
    suspended = request.args.get('suspended', '').strip()
    page = request.args.get('page', 1, type=int)

    query = Store.query
    if search:
        query = query.filter(db.or_(
            Store.name.ilike(f'%{search}%'),
            Store.slug.ilike(f'%{search}%'),
            Store.wilaya.ilike(f'%{search}%'),
        ))
    if verification:
        query = query.filter_by(verification_status=verification)
    if suspended == 'yes':
        query = query.filter_by(is_suspended=True)
    elif suspended == 'no':
        query = query.filter_by(is_suspended=False)

    stores = query.order_by(Store.created_at.desc()).paginate(page=page, per_page=20, error_out=False)
    return render_template('admin/stores.html', stores=stores, search=search,
                           verification_filter=verification, suspended_filter=suspended)


@admin_bp.route('/stores/<int:store_id>/verify', methods=['POST'])
@login_required
@admin_required
def verify_store(store_id):
    store = Store.query.get_or_404(store_id)
    action = request.form.get('action')

    if action == 'approve':
        store.verification_status = 'approved'
        store.verified_at = datetime.utcnow()
        notify(store.user_id, 'verification_approved',
               'Boutique vérifiée ✅',
               f'Votre boutique "{store.name}" a été approuvée et vérifiée.',
               store_id=store.id, action_url=url_for('dashboard.index'))
        flash(f'Boutique "{store.name}" approuvée.', 'success')
    elif action == 'reject':
        reason = request.form.get('reason', 'Documents incomplets ou invalides.')
        store.verification_status = 'rejected'
        notify(store.user_id, 'verification_rejected',
               'Vérification rejetée ❌',
               f'Votre boutique "{store.name}" n\'a pas pu être vérifiée. Raison: {reason}',
               store_id=store.id, action_url=url_for('store.settings'))
        flash(f'Boutique "{store.name}" rejetée.', 'info')

    db.session.commit()
    return redirect(url_for('admin.stores'))


@admin_bp.route('/stores/<int:store_id>/suspend', methods=['POST'])
@login_required
@admin_required
def suspend_store(store_id):
    store = Store.query.get_or_404(store_id)
    reason = request.form.get('reason', 'Violation des conditions d\'utilisation.')
    store.is_suspended = not store.is_suspended
    store.suspension_reason = reason if store.is_suspended else None
    if store.is_suspended:
        notify(store.user_id, 'store_suspended',
               f'Boutique suspendue',
               f'Votre boutique "{store.name}" a été suspendue. Raison: {reason}',
               store_id=store.id)
    db.session.commit()
    status = 'suspendue' if store.is_suspended else 'réactivée'
    flash(f'Boutique {status}.', 'success')
    return redirect(url_for('admin.stores'))


@admin_bp.route('/subscriptions')
@login_required
@admin_required
def subscriptions():
    plan_filter = request.args.get('plan', '').strip()
    status_filter = request.args.get('status', '').strip()
    page = request.args.get('page', 1, type=int)

    query = Subscription.query.join(Store)
    if plan_filter:
        query = query.filter(Subscription.plan == plan_filter)
    if status_filter:
        query = query.filter(Subscription.status == status_filter)

    subs = query.order_by(Subscription.created_at.desc()).paginate(page=page, per_page=20, error_out=False)

    plan_counts = {}
    for plan in ['starter', 'professional', 'business']:
        plan_counts[plan] = Subscription.query.filter_by(plan=plan).count()

    status_counts = {}
    for s in ['active', 'trial', 'expired', 'suspended', 'cancelled']:
        status_counts[s] = Subscription.query.filter_by(status=s).count()

    expiring_soon = Subscription.query.filter(
        Subscription.status.in_(['active', 'trial']),
        Subscription.expires_at.isnot(None),
        Subscription.expires_at <= datetime.utcnow() + timedelta(days=7),
        Subscription.expires_at >= datetime.utcnow()
    ).count()

    return render_template('admin/subscriptions.html',
        subs=subs, plan_filter=plan_filter, status_filter=status_filter,
        plan_counts=plan_counts, status_counts=status_counts, expiring_soon=expiring_soon,
        PLANS=Subscription.PLANS)


@admin_bp.route('/subscriptions/<int:sub_id>/change-plan', methods=['POST'])
@login_required
@admin_required
def change_subscription(sub_id):
    sub = Subscription.query.get_or_404(sub_id)
    new_plan = request.form.get('plan')
    new_status = request.form.get('status')
    expires_days = request.form.get('expires_days', type=int)

    if new_plan and new_plan in Subscription.PLANS:
        sub.plan = new_plan
        sub.price_dzd = Subscription.PLANS[new_plan]['price']
    if new_status and new_status in ['active', 'trial', 'expired', 'suspended', 'cancelled']:
        sub.status = new_status
    if expires_days:
        sub.expires_at = datetime.utcnow() + timedelta(days=expires_days)

    db.session.commit()
    notify(sub.store.user_id, 'subscription_upgrade',
           'Abonnement mis à jour 🚀',
           f'Votre abonnement a été modifié vers le plan {sub.plan.capitalize()}.',
           store_id=sub.store_id, action_url=url_for('store.settings'))
    flash('Abonnement mis à jour.', 'success')
    return redirect(url_for('admin.subscriptions'))
