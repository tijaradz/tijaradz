from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from app import db
from app.models.user import User
from app.models.store import Store
from app.models.subscription import Subscription

auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard.index'))

    if request.method == 'POST':
        full_name = request.form.get('full_name', '').strip()
        username = request.form.get('username', '').strip().lower()
        email = request.form.get('email', '').strip().lower()
        phone = request.form.get('phone', '').strip()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')

        errors = []
        if not full_name:
            errors.append('Le nom complet est requis.')
        if not username or len(username) < 3:
            errors.append("Le nom d'utilisateur doit contenir au moins 3 caractères.")
        if not email or '@' not in email:
            errors.append('Email invalide.')
        if len(password) < 8:
            errors.append('Le mot de passe doit contenir au moins 8 caractères.')
        if password != confirm_password:
            errors.append('Les mots de passe ne correspondent pas.')
        if User.query.filter_by(email=email).first():
            errors.append('Cet email est déjà utilisé.')
        if User.query.filter_by(username=username).first():
            errors.append("Ce nom d'utilisateur est déjà pris.")

        if errors:
            for error in errors:
                flash(error, 'error')
            return render_template('auth/register.html')

        user = User(full_name=full_name, username=username, email=email, phone=phone)
        user.set_password(password)
        db.session.add(user)
        db.session.flush()

        login_user(user, remember=True)
        db.session.commit()
        flash('Compte créé avec succès ! Bienvenue sur TijariDZ.', 'success')
        return redirect(url_for('store.create'))

    return render_template('auth/register.html')


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard.index'))

    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        remember = request.form.get('remember') == 'on'

        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            login_user(user, remember=remember)
            next_page = request.args.get('next')
            flash('Connexion réussie !', 'success')
            return redirect(next_page or url_for('dashboard.index'))
        else:
            flash('Email ou mot de passe incorrect.', 'error')

    return render_template('auth/login.html')


@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Vous avez été déconnecté.', 'info')
    return redirect(url_for('landing.index'))
