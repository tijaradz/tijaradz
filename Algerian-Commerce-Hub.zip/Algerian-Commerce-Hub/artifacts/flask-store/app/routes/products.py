import os
import uuid
from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from app import db
from app.models.store import Store
from app.models.product import Product

products_bp = Blueprint('products', __name__)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
CATEGORIES = [
    'Mode & Vêtements', 'Électronique', 'Alimentation & Boissons', 'Maison & Jardin',
    'Beauté & Soins', 'Sport & Loisirs', 'Jouets & Enfants', 'Automobile',
    'Livres & Médias', 'Santé', 'Artisanat', 'Informatique', 'Téléphonie', 'Autre',
]


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def get_store():
    return Store.query.filter_by(user_id=current_user.id).first()


def save_image(file):
    if not file or file.filename == '':
        return None
    if not allowed_file(file.filename):
        return None
    ext = file.filename.rsplit('.', 1)[1].lower()
    filename = f"{uuid.uuid4().hex}.{ext}"
    file.save(os.path.join(current_app.config['UPLOAD_FOLDER'], filename))
    return f"uploads/products/{filename}"


@products_bp.route('/')
@login_required
def index():
    store = get_store()
    if not store:
        return redirect(url_for('store.create'))

    search = request.args.get('search', '').strip()
    category = request.args.get('category', '').strip()
    status = request.args.get('status', '').strip()

    query = Product.query.filter_by(store_id=store.id)
    if search:
        query = query.filter(Product.name.ilike(f'%{search}%'))
    if category:
        query = query.filter_by(category=category)
    if status == 'active':
        query = query.filter_by(is_active=True)
    elif status == 'inactive':
        query = query.filter_by(is_active=False)

    products = query.order_by(Product.created_at.desc()).all()
    total_count = Product.query.filter_by(store_id=store.id).count()
    active_count = Product.query.filter_by(store_id=store.id, is_active=True).count()
    low_stock_count = Product.query.filter(
        Product.store_id == store.id,
        Product.stock <= 5,
        Product.stock > 0,
        Product.is_active == True
    ).count()
    out_of_stock = Product.query.filter_by(store_id=store.id, stock=0).count()

    return render_template(
        'products/index.html',
        store=store,
        products=products,
        categories=CATEGORIES,
        total_count=total_count,
        active_count=active_count,
        low_stock_count=low_stock_count,
        out_of_stock=out_of_stock,
        search=search,
        selected_category=category,
        selected_status=status,
    )


@products_bp.route('/create', methods=['GET', 'POST'])
@login_required
def create():
    store = get_store()
    if not store:
        return redirect(url_for('store.create'))

    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        description = request.form.get('description', '').strip()
        price_raw = request.form.get('price', '0').strip()
        stock_raw = request.form.get('stock', '0').strip()
        sku = request.form.get('sku', '').strip()
        category = request.form.get('category', '').strip()
        is_active = request.form.get('is_active') == 'on'

        errors = []
        if not name:
            errors.append('Le nom du produit est requis.')
        try:
            price = float(price_raw)
            if price < 0:
                errors.append('Le prix ne peut pas être négatif.')
        except ValueError:
            errors.append('Prix invalide.')
            price = 0
        try:
            stock = int(stock_raw)
            if stock < 0:
                errors.append('Le stock ne peut pas être négatif.')
        except ValueError:
            errors.append('Stock invalide.')
            stock = 0

        if errors:
            for e in errors:
                flash(e, 'error')
            return render_template('products/create.html', store=store, categories=CATEGORIES)

        image_url = None
        if 'image' in request.files:
            image_url = save_image(request.files['image'])

        product = Product(
            store_id=store.id,
            name=name,
            description=description,
            price=price,
            stock=stock,
            sku=sku or None,
            category=category or None,
            image_url=image_url,
            is_active=is_active,
        )
        db.session.add(product)
        db.session.commit()
        flash('Produit créé avec succès !', 'success')
        return redirect(url_for('products.index'))

    return render_template('products/create.html', store=store, categories=CATEGORIES)


@products_bp.route('/<int:product_id>/edit', methods=['GET', 'POST'])
@login_required
def edit(product_id):
    store = get_store()
    product = Product.query.filter_by(id=product_id, store_id=store.id).first_or_404()

    if request.method == 'POST':
        product.name = request.form.get('name', '').strip()
        product.description = request.form.get('description', '').strip()
        try:
            product.price = float(request.form.get('price', '0'))
        except ValueError:
            product.price = 0
        try:
            product.stock = int(request.form.get('stock', '0'))
        except ValueError:
            product.stock = 0
        product.sku = request.form.get('sku', '').strip() or None
        product.category = request.form.get('category', '').strip() or None
        product.is_active = request.form.get('is_active') == 'on'

        if 'image' in request.files and request.files['image'].filename:
            new_url = save_image(request.files['image'])
            if new_url:
                if product.image_url:
                    old_path = os.path.join(current_app.root_path, 'static', product.image_url)
                    if os.path.exists(old_path):
                        os.remove(old_path)
                product.image_url = new_url

        if request.form.get('remove_image') == 'yes' and product.image_url:
            old_path = os.path.join(current_app.root_path, 'static', product.image_url)
            if os.path.exists(old_path):
                os.remove(old_path)
            product.image_url = None

        db.session.commit()
        flash('Produit mis à jour avec succès !', 'success')
        return redirect(url_for('products.index'))

    return render_template('products/edit.html', store=store, product=product, categories=CATEGORIES)


@products_bp.route('/<int:product_id>/delete', methods=['POST'])
@login_required
def delete(product_id):
    store = get_store()
    product = Product.query.filter_by(id=product_id, store_id=store.id).first_or_404()

    if product.image_url:
        path = os.path.join(current_app.root_path, 'static', product.image_url)
        if os.path.exists(path):
            os.remove(path)

    db.session.delete(product)
    db.session.commit()
    flash('Produit supprimé.', 'info')
    return redirect(url_for('products.index'))


@products_bp.route('/<int:product_id>/toggle', methods=['POST'])
@login_required
def toggle(product_id):
    store = get_store()
    product = Product.query.filter_by(id=product_id, store_id=store.id).first_or_404()
    product.is_active = not product.is_active
    db.session.commit()
    status = 'activé' if product.is_active else 'désactivé'
    flash(f'Produit {status}.', 'success')
    return redirect(url_for('products.index'))
