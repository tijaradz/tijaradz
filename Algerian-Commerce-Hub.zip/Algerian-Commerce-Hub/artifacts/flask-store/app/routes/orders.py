from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app import db
from app.models.store import Store
from app.models.order import Order

orders_bp = Blueprint('orders', __name__)

STATUS_FLOW = {
    'pending': ['confirmed', 'cancelled'],
    'confirmed': ['processing', 'cancelled'],
    'processing': ['shipped', 'cancelled'],
    'shipped': ['delivered'],
    'delivered': ['completed'],
    'completed': [],
    'cancelled': [],
}

STATUS_COLORS = {
    'pending': ('amber', 'En attente'),
    'confirmed': ('blue', 'Confirmé'),
    'processing': ('indigo', 'En cours'),
    'shipped': ('cyan', 'Expédié'),
    'delivered': ('teal', 'Livré'),
    'completed': ('emerald', 'Terminé'),
    'cancelled': ('red', 'Annulé'),
}


def get_store():
    return Store.query.filter_by(user_id=current_user.id).first()


@orders_bp.route('/')
@login_required
def index():
    store = get_store()
    if not store:
        return redirect(url_for('store.create'))

    status_filter = request.args.get('status', '').strip()
    search = request.args.get('search', '').strip()
    page = request.args.get('page', 1, type=int)

    query = Order.query.filter_by(store_id=store.id)
    if status_filter:
        query = query.filter_by(status=status_filter)
    if search:
        query = query.filter(
            db.or_(
                Order.customer_name.ilike(f'%{search}%'),
                Order.order_number.ilike(f'%{search}%'),
                Order.customer_phone.ilike(f'%{search}%'),
            )
        )

    orders = query.order_by(Order.created_at.desc()).paginate(page=page, per_page=20, error_out=False)

    status_counts = {}
    for s in Order.STATUS_CHOICES:
        status_counts[s] = Order.query.filter_by(store_id=store.id, status=s).count()
    total_count = Order.query.filter_by(store_id=store.id).count()

    return render_template(
        'orders/index.html',
        store=store,
        orders=orders,
        status_filter=status_filter,
        search=search,
        status_counts=status_counts,
        total_count=total_count,
        STATUS_COLORS=STATUS_COLORS,
        STATUS_CHOICES=Order.STATUS_CHOICES,
    )


@orders_bp.route('/<int:order_id>')
@login_required
def detail(order_id):
    store = get_store()
    order = Order.query.filter_by(id=order_id, store_id=store.id).first_or_404()
    next_statuses = STATUS_FLOW.get(order.status, [])
    return render_template(
        'orders/detail.html',
        store=store,
        order=order,
        next_statuses=next_statuses,
        STATUS_COLORS=STATUS_COLORS,
    )


@orders_bp.route('/<int:order_id>/update-status', methods=['POST'])
@login_required
def update_status(order_id):
    store = get_store()
    order = Order.query.filter_by(id=order_id, store_id=store.id).first_or_404()
    new_status = request.form.get('status', '')
    allowed = STATUS_FLOW.get(order.status, [])
    if new_status in allowed:
        order.status = new_status
        db.session.commit()
        label = STATUS_COLORS.get(new_status, ('', new_status))[1]
        flash(f'Commande mise à jour : {label}', 'success')
    else:
        flash('Transition de statut non autorisée.', 'error')
    return redirect(url_for('orders.detail', order_id=order.id))
