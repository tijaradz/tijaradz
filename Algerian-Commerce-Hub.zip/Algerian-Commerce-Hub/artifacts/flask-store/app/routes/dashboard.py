from flask import Blueprint, render_template, redirect, url_for, flash
from flask_login import login_required, current_user
from app import db
from app.models.store import Store
from app.models.order import Order
from app.models.product import Product

dashboard_bp = Blueprint('dashboard', __name__)


def get_current_store():
    return Store.query.filter_by(user_id=current_user.id, is_active=True).first()


@dashboard_bp.route('/')
@login_required
def index():
    store = get_current_store()
    if not store:
        flash('Créez votre boutique pour commencer.', 'info')
        return redirect(url_for('store.create'))

    total_orders = store.orders.count()
    total_revenue = store.get_total_revenue()
    products_count = store.products.filter_by(is_active=True).count()
    pending_orders = store.orders.filter_by(status='pending').count()
    completed_orders = store.orders.filter_by(status='completed').count()

    recent_orders = store.orders.order_by(Order.created_at.desc()).limit(8).all()

    # Revenue chart: last 6 months
    monthly_revenue = db.session.query(
        db.func.to_char(Order.created_at, 'Mon YYYY').label('month'),
        db.func.sum(Order.total_amount).label('revenue')
    ).filter(
        Order.store_id == store.id,
        Order.status == 'completed'
    ).group_by(
        db.func.date_trunc('month', Order.created_at),
        db.func.to_char(Order.created_at, 'Mon YYYY')
    ).order_by(db.func.date_trunc('month', Order.created_at)).limit(6).all()

    revenue_labels = [r.month for r in monthly_revenue]
    revenue_data = [float(r.revenue) for r in monthly_revenue]

    # Status breakdown for donut chart
    STATUS_INFO = [
        ('pending', 'En attente', '#f59e0b'),
        ('confirmed', 'Confirmé', '#3b82f6'),
        ('processing', 'En cours', '#6366f1'),
        ('shipped', 'Expédié', '#06b6d4'),
        ('delivered', 'Livré', '#14b8a6'),
        ('completed', 'Terminé', '#10b981'),
        ('cancelled', 'Annulé', '#ef4444'),
    ]
    status_breakdown = []
    status_labels = []
    status_data = []
    status_colors = []
    for key, label, color in STATUS_INFO:
        count = store.orders.filter_by(status=key).count()
        if count > 0:
            status_breakdown.append(((key, count), label, color))
            status_labels.append(label)
            status_data.append(count)
            status_colors.append(color)

    # Low stock alert
    low_stock_products = Product.query.filter(
        Product.store_id == store.id,
        Product.stock <= 5,
        Product.is_active == True
    ).order_by(Product.stock.asc()).limit(5).all()

    return render_template(
        'dashboard/index.html',
        store=store,
        total_orders=total_orders,
        total_revenue=total_revenue,
        products_count=products_count,
        pending_orders=pending_orders,
        completed_orders=completed_orders,
        recent_orders=recent_orders,
        monthly_revenue=monthly_revenue,
        revenue_labels=revenue_labels,
        revenue_data=revenue_data,
        status_breakdown=status_breakdown,
        status_labels=status_labels,
        status_data=status_data,
        status_colors=status_colors,
        low_stock_products=low_stock_products,
    )
