"""
Algerian wilaya shipping rates and delivery estimates.
Zones: 1=Alger metro, 2=Nord, 3=Nord-Est, 4=Nord-Ouest, 5=Hauts Plateaux, 6=Grand Sud
"""
from urllib.parse import quote

WILAYA_SHIPPING = {
    # Zone 1 — Alger métropole (1-2 jours)
    'Alger':      {'fee': 300, 'days': '1-2 jours', 'zone': 1},
    'Blida':      {'fee': 350, 'days': '1-2 jours', 'zone': 1},
    'Boumerdès':  {'fee': 350, 'days': '1-2 jours', 'zone': 1},
    'Tipaza':     {'fee': 350, 'days': '1-2 jours', 'zone': 1},

    # Zone 2 — Nord-Centre (2-3 jours)
    'Tizi Ouzou': {'fee': 400, 'days': '2-3 jours', 'zone': 2},
    'Béjaïa':     {'fee': 400, 'days': '2-3 jours', 'zone': 2},
    'Bouira':     {'fee': 400, 'days': '2-3 jours', 'zone': 2},
    'Médéa':      {'fee': 400, 'days': '2-3 jours', 'zone': 2},
    'Aïn Defla':  {'fee': 450, 'days': '2-3 jours', 'zone': 2},
    'Chlef':      {'fee': 450, 'days': '2-3 jours', 'zone': 2},
    'Tissemsilt': {'fee': 450, 'days': '2-3 jours', 'zone': 2},
    'Jijel':      {'fee': 450, 'days': '2-3 jours', 'zone': 2},
    'Mostaganem': {'fee': 450, 'days': '2-3 jours', 'zone': 2},

    # Zone 3 — Nord-Est (2-4 jours)
    'Constantine':      {'fee': 500, 'days': '2-4 jours', 'zone': 3},
    'Annaba':           {'fee': 500, 'days': '2-4 jours', 'zone': 3},
    'Skikda':           {'fee': 500, 'days': '2-4 jours', 'zone': 3},
    'Sétif':            {'fee': 500, 'days': '2-4 jours', 'zone': 3},
    'Guelma':           {'fee': 500, 'days': '2-4 jours', 'zone': 3},
    'Batna':            {'fee': 500, 'days': '2-4 jours', 'zone': 3},
    'Mila':             {'fee': 500, 'days': '2-4 jours', 'zone': 3},
    'Bordj Bou Arréridj': {'fee': 500, 'days': '3-4 jours', 'zone': 3},
    'Oum El Bouaghi':   {'fee': 550, 'days': '3-4 jours', 'zone': 3},
    'Souk Ahras':       {'fee': 550, 'days': '3-4 jours', 'zone': 3},
    'El Tarf':          {'fee': 550, 'days': '3-4 jours', 'zone': 3},
    'Khenchela':        {'fee': 550, 'days': '3-5 jours', 'zone': 3},
    'Tébessa':          {'fee': 600, 'days': '3-5 jours', 'zone': 3},

    # Zone 4 — Nord-Ouest (2-4 jours)
    'Oran':          {'fee': 500, 'days': '2-4 jours', 'zone': 4},
    'Tlemcen':       {'fee': 500, 'days': '2-4 jours', 'zone': 4},
    'Sidi Bel Abbès': {'fee': 500, 'days': '2-4 jours', 'zone': 4},
    'Saïda':         {'fee': 500, 'days': '3-4 jours', 'zone': 4},
    'Tiaret':        {'fee': 500, 'days': '3-4 jours', 'zone': 4},
    'Mascara':       {'fee': 500, 'days': '3-4 jours', 'zone': 4},
    'Relizane':      {'fee': 500, 'days': '3-4 jours', 'zone': 4},
    'Aïn Témouchent': {'fee': 550, 'days': '3-4 jours', 'zone': 4},
    'Naâma':         {'fee': 600, 'days': '4-5 jours', 'zone': 4},

    # Zone 5 — Hauts Plateaux / Centre-Sud (3-6 jours)
    'Djelfa':   {'fee': 600, 'days': '3-5 jours', 'zone': 5},
    "M'Sila":   {'fee': 600, 'days': '3-5 jours', 'zone': 5},
    'Biskra':   {'fee': 600, 'days': '3-5 jours', 'zone': 5},
    'Laghouat': {'fee': 650, 'days': '4-6 jours', 'zone': 5},
    'El Bayadh': {'fee': 700, 'days': '4-6 jours', 'zone': 5},
    'Ghardaïa': {'fee': 700, 'days': '4-6 jours', 'zone': 5},
    'Béchar':   {'fee': 750, 'days': '5-7 jours', 'zone': 5},
    'El Oued':  {'fee': 700, 'days': '4-6 jours', 'zone': 5},
    'Ouargla':  {'fee': 700, 'days': '4-6 jours', 'zone': 5},

    # Zone 6 — Grand Sud (6-10 jours)
    'Tamanrasset': {'fee': 900,  'days': '6-8 jours',  'zone': 6},
    'Adrar':       {'fee': 900,  'days': '6-8 jours',  'zone': 6},
    'Illizi':      {'fee': 950,  'days': '6-9 jours',  'zone': 6},
    'Tindouf':     {'fee': 1000, 'days': '7-10 jours', 'zone': 6},
}

DEFAULT_SHIPPING = {'fee': 600, 'days': '4-6 jours', 'zone': 5}


def get_shipping_info(wilaya, free_threshold=0, order_subtotal=0):
    """Return shipping dict with fee, days, zone, is_free."""
    info = dict(WILAYA_SHIPPING.get(wilaya, DEFAULT_SHIPPING))
    threshold = float(free_threshold or 0)
    if threshold > 0 and float(order_subtotal or 0) >= threshold:
        info['fee'] = 0
        info['is_free'] = True
    else:
        info['is_free'] = False
    return info


def shipping_rates_json():
    """Return all wilaya rates as a plain dict (for JS)."""
    return {w: {'fee': d['fee'], 'days': d['days']} for w, d in WILAYA_SHIPPING.items()}


def normalize_whatsapp(number):
    """Convert Algerian number to international format for wa.me."""
    if not number:
        return ''
    n = number.strip().replace(' ', '').replace('-', '').replace('.', '')
    if n.startswith('+'):
        return n[1:]
    if n.startswith('00'):
        return n[2:]
    if n.startswith('0'):
        return '213' + n[1:]
    return n


def build_whatsapp_url(whatsapp_number, message):
    num = normalize_whatsapp(whatsapp_number)
    return f'https://wa.me/{num}?text={quote(message)}'


def build_order_whatsapp_message(order, items):
    parts = [
        f'🛍️ Nouvelle commande #{order.order_number}',
        '━━━━━━━━━━━━━━━━━━',
        f'👤 Client: {order.customer_name}',
        f'📞 Tél: {order.customer_phone}',
        f'📍 Adresse: {order.wilaya}' +
        (f', {order.commune}' if order.commune else '') +
        f' — {order.customer_address}',
        '',
        '🛒 Articles commandés:',
    ]
    subtotal = 0
    for item in items:
        line_total = item['qty'] * item['unit_price']
        subtotal += line_total
        parts.append(f'  • {item["product"].name} × {item["qty"]} = {line_total:.0f} DZD')

    shipping = float(order.shipping_cost or 0)
    parts += [
        '',
        f'💰 Sous-total: {subtotal:.0f} DZD',
        f'🚚 Livraison: {"Gratuite" if shipping == 0 else f"{shipping:.0f} DZD"}',
        f'✅ Total: {float(order.total_amount):.0f} DZD',
        '',
        '💳 Paiement: à la livraison (COD)',
    ]
    if order.delivery_estimate:
        parts.append(f'⏱️ Délai estimé: {order.delivery_estimate}')
    if order.notes:
        parts.append(f'📝 Notes: {order.notes}')
    return '\n'.join(parts)
