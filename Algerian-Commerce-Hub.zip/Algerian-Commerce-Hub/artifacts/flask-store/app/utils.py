from functools import wraps
from flask import abort, flash, redirect, url_for
from flask_login import current_user


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for('auth.login'))
        if not current_user.is_admin:
            abort(403)
        return f(*args, **kwargs)
    return decorated


def notify(user_id, notif_type, title, message, store_id=None, action_url=None):
    """Create a notification for a user. Silently ignores errors."""
    try:
        from app import db
        from app.models.notification import Notification
        n = Notification(
            user_id=user_id,
            store_id=store_id,
            type=notif_type,
            title=title,
            message=message,
            action_url=action_url,
        )
        db.session.add(n)
        db.session.flush()
    except Exception:
        pass


def notify_all_admins(notif_type, title, message, store_id=None, action_url=None):
    """Send a notification to all admin users."""
    try:
        from app.models.user import User
        admins = User.query.filter_by(is_admin=True).all()
        for admin in admins:
            notify(admin.id, notif_type, title, message, store_id=store_id, action_url=action_url)
    except Exception:
        pass
