from datetime import datetime, timedelta
from app import db


class Subscription(db.Model):
    __tablename__ = 'subscriptions'

    id = db.Column(db.Integer, primary_key=True)
    store_id = db.Column(db.Integer, db.ForeignKey('stores.id'), nullable=False, index=True)
    plan = db.Column(db.String(50), nullable=False, default='starter')
    status = db.Column(db.String(50), nullable=False, default='active')
    price_dzd = db.Column(db.Numeric(10, 2), nullable=False, default=0)
    billing_cycle = db.Column(db.String(20), default='monthly')
    started_at = db.Column(db.DateTime, default=datetime.utcnow)
    trial_ends_at = db.Column(db.DateTime)
    expires_at = db.Column(db.DateTime)
    cancelled_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    PLANS = {
        'starter': {
            'name': 'Starter',
            'price': 0,
            'products': 10,
            'orders': 50,
            'trial_days': 0,
            'color': 'slate',
            'features': ['1 boutique', '10 produits', '50 commandes/mois', 'Tableau de bord', 'Support email'],
        },
        'professional': {
            'name': 'Professional',
            'price': 4900,
            'products': 200,
            'orders': 1000,
            'trial_days': 14,
            'color': 'brand',
            'features': ['1 boutique', '200 produits', '1000 commandes/mois', 'Statistiques avancées', 'Support prioritaire', 'Personnalisation avancée'],
        },
        'business': {
            'name': 'Business',
            'price': 9900,
            'products': -1,
            'orders': -1,
            'trial_days': 14,
            'color': 'purple',
            'features': ['Boutiques illimitées', 'Produits illimités', 'Commandes illimitées', 'API dédiée', 'Manager dédié', 'SLA garanti'],
        },
    }

    STATUS_LABELS = {
        'trial': ('Essai gratuit', 'emerald'),
        'active': ('Actif', 'emerald'),
        'expired': ('Expiré', 'red'),
        'suspended': ('Suspendu', 'amber'),
        'cancelled': ('Annulé', 'slate'),
    }

    def is_subscription_active(self):
        now = datetime.utcnow()
        if self.status == 'trial' and self.trial_ends_at and self.trial_ends_at > now:
            return True
        if self.status == 'active':
            if self.expires_at and self.expires_at < now:
                return False
            return True
        return False

    def days_until_expiry(self):
        now = datetime.utcnow()
        target = self.trial_ends_at if self.status == 'trial' else self.expires_at
        if target:
            delta = target - now
            return max(0, delta.days)
        return None

    def is_expiring_soon(self, days=7):
        d = self.days_until_expiry()
        return d is not None and d <= days

    def get_status_label(self):
        return self.STATUS_LABELS.get(self.status, (self.status, 'slate'))

    def get_plan_info(self):
        return self.PLANS.get(self.plan, self.PLANS['starter'])

    def upgrade_to(self, new_plan, billing_cycle='monthly'):
        plan_info = self.PLANS.get(new_plan)
        if not plan_info:
            return False
        self.plan = new_plan
        self.billing_cycle = billing_cycle
        self.price_dzd = plan_info['price']
        now = datetime.utcnow()
        if plan_info['trial_days'] > 0 and self.status == 'active' and self.plan == 'starter':
            self.status = 'trial'
            self.trial_ends_at = now + timedelta(days=plan_info['trial_days'])
        else:
            self.status = 'active'
            self.expires_at = now + timedelta(days=365 if billing_cycle == 'yearly' else 30)
        self.updated_at = now
        return True

    def __repr__(self):
        return f'<Subscription {self.plan} - {self.status}>'
