from datetime import datetime
from app import db


class Order(db.Model):
    __tablename__ = 'orders'

    id = db.Column(db.Integer, primary_key=True)
    store_id = db.Column(db.Integer, db.ForeignKey('stores.id'), nullable=False, index=True)
    order_number = db.Column(db.String(50), unique=True, nullable=False)
    customer_name = db.Column(db.String(255), nullable=False)
    customer_email = db.Column(db.String(255))
    customer_phone = db.Column(db.String(20))
    customer_address = db.Column(db.Text)
    wilaya = db.Column(db.String(100))
    commune = db.Column(db.String(100))
    shipping_cost = db.Column(db.Numeric(10, 2), default=0)
    delivery_estimate = db.Column(db.String(50))
    total_amount = db.Column(db.Numeric(10, 2), nullable=False, default=0)
    status = db.Column(db.String(50), nullable=False, default='pending')
    payment_method = db.Column(db.String(50), default='cash_on_delivery')
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    STATUS_CHOICES = ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'completed', 'cancelled']
    STATUS_LABELS = {
        'pending': 'En attente',
        'confirmed': 'Confirmé',
        'processing': 'En cours',
        'shipped': 'Expédié',
        'delivered': 'Livré',
        'completed': 'Terminé',
        'cancelled': 'Annulé',
    }

    def get_status_label(self):
        return self.STATUS_LABELS.get(self.status, self.status)

    def __repr__(self):
        return f'<Order {self.order_number}>'
