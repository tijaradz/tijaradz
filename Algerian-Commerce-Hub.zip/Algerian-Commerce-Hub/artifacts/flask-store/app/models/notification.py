from datetime import datetime
from app import db


class Notification(db.Model):
    __tablename__ = 'notifications'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    store_id = db.Column(db.Integer, db.ForeignKey('stores.id'), nullable=True)
    type = db.Column(db.String(50), nullable=False)
    title = db.Column(db.String(255), nullable=False)
    message = db.Column(db.Text, nullable=False)
    action_url = db.Column(db.String(512))
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    TYPES = {
        'new_order': {'icon': '🛒', 'color': 'blue'},
        'low_stock': {'icon': '⚠️', 'color': 'amber'},
        'subscription_expiry': {'icon': '⏳', 'color': 'orange'},
        'verification_approved': {'icon': '✅', 'color': 'emerald'},
        'verification_rejected': {'icon': '❌', 'color': 'red'},
        'subscription_upgrade': {'icon': '🚀', 'color': 'purple'},
        'store_suspended': {'icon': '🚫', 'color': 'red'},
        'system': {'icon': 'ℹ️', 'color': 'slate'},
    }

    def get_type_info(self):
        return self.TYPES.get(self.type, self.TYPES['system'])

    def mark_read(self):
        self.is_read = True

    def __repr__(self):
        return f'<Notification {self.type} user={self.user_id}>'
