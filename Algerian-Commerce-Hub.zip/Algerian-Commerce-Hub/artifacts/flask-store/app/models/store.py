from datetime import datetime
from app import db


class Store(db.Model):
    __tablename__ = 'stores'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    name = db.Column(db.String(255), nullable=False)
    slug = db.Column(db.String(255), unique=True, nullable=False, index=True)
    description = db.Column(db.Text)
    logo_url = db.Column(db.String(512))
    banner_url = db.Column(db.String(512))
    primary_color = db.Column(db.String(20), default='#2563eb')
    secondary_color = db.Column(db.String(20), default='#7c3aed')

    # Contact
    phone = db.Column(db.String(20))
    whatsapp = db.Column(db.String(30))
    email = db.Column(db.String(255))
    address = db.Column(db.Text)
    wilaya = db.Column(db.String(100))
    category = db.Column(db.String(100))
    business_hours = db.Column(db.Text)

    # Social media
    facebook_url = db.Column(db.String(255))
    instagram_url = db.Column(db.String(255))
    tiktok_url = db.Column(db.String(255))
    youtube_url = db.Column(db.String(255))
    telegram_url = db.Column(db.String(255))

    # Shipping
    free_shipping_threshold = db.Column(db.Numeric(10, 2), default=0)

    # Status
    is_active = db.Column(db.Boolean, default=True)
    is_suspended = db.Column(db.Boolean, default=False)
    suspension_reason = db.Column(db.Text)
    verification_status = db.Column(db.String(50), default='pending')
    verified_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    products = db.relationship('Product', backref='store', lazy='dynamic', cascade='all, delete-orphan')
    orders = db.relationship('Order', backref='store', lazy='dynamic', cascade='all, delete-orphan')
    subscription = db.relationship('Subscription', backref='store', uselist=False, cascade='all, delete-orphan')

    def get_total_revenue(self):
        from app.models.order import Order
        return db.session.query(db.func.sum(Order.total_amount)).filter(
            Order.store_id == self.id,
            Order.status == 'completed'
        ).scalar() or 0

    def get_orders_count(self):
        return self.orders.count()

    def get_products_count(self):
        return self.products.count()

    def __repr__(self):
        return f'<Store {self.name}>'
